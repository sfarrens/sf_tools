# sf_tools

> Author: <font color='#f78c40'>Samuel Farrens</font>
> Year: 2017
> Email: [samuel.farrens@gmail.com](mailto:samuel.farrens@gmail.com)
> Website: <a href="https://sfarrens.github.io"
target="_blank">https://sfarrens.github.io</a>

sf_tools is a series of Python 2.7 modules with applications to signal
processing and statistics.

Extensive documentation coming soon!
