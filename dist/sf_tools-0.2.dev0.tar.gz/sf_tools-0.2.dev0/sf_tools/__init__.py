# -*- coding: utf-8 -*-

"""CREEPY PACKAGE

This package contains modules for astrophysics, cosmology and signal
processing.

:Author: Samuel Farrens <samuel.farrens@gmail.com>

:Version: 1.0

:Date: 06/04/2017

"""
