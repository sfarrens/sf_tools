# sf_tools

Author: Samuel Farrens
Year: 2017
Email: samuel.farrens@gmail.com
Website: https://sfarrens.github.io

sf_tools is a series of Python modules with applications to image analysis, signal
processing and statistics.

Full documentation available here: https://sfarrens.github.io/sf_tools/